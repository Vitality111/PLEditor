document.querySelectorAll('#scrollContent').forEach(scrollContent => {
    const nodes = Array.from(scrollContent.childNodes);
    nodes.forEach(node => {
        if (node.nodeType === Node.TEXT_NODE) {
            let text = node.textContent;
            text = text.replace(/(?:\r?\n){2,}/g, '<br><br>');
            text = text.replace(/\r?\n/g, ' ');
            const span = document.createElement('span');
            span.innerHTML = text;
            scrollContent.replaceChild(span, node);
        }
    });
});
document.addEventListener('contextmenu', e => e.preventDefault()), document.addEventListener('selectstart', e => e.preventDefault()), ['img', 'video', 'audio'].forEach(e => { document.querySelectorAll(e).forEach(e => { e.setAttribute('draggable', 'false'), e.style.webkitTouchCallout = 'none', e.style.userSelect = 'none' }) });
// ==== (iOS / Android) ====
const IOS_URL = 'https://apps.apple.com/us/app/fictionme-stories-novels/id1630170714';
const ANDROID_URL = 'https://play.google.com/store/apps/details?id=com.fiction.me&pli=1';

function isIOS() {
    return /iPad|iPhone|iPod/i.test(navigator.userAgent) || /iOS/i.test(navigator.platform);
}

function getStoreUrl() {
    return isIOS() ? IOS_URL : ANDROID_URL;
}

let ctaLocked = false;
function lockCTA(ms = 1500) {
    ctaLocked = true;
    setTimeout(() => (ctaLocked = false), ms);
}

function handleCTA() {
    if (ctaLocked) return;
    lockCTA();

    const url = getStoreUrl();

    try {
        if (typeof FbPlayableAd !== 'undefined' && typeof FbPlayableAd.onCTAClick === 'function') {
            FbPlayableAd.onCTAClick();
            return;
        }
    } catch (e) {
        console.warn('CTA error (Facebook):', e);
    }

    try {
        if (typeof AL !== 'undefined') {
            if (typeof AL.openStoreUrl === 'function') {
                try { AL.openStoreUrl(); return; } catch (_) { }
                try { AL.openStoreUrl(url); return; } catch (_) { }
            }

            if (typeof AL.openUrl === 'function') {
                AL.openUrl(url);
                return;
            }
        }
    } catch (e) {
        console.warn('CTA error (AppLovin):', e);
    }

    try {
        if (typeof mraid !== 'undefined' && typeof mraid.open === 'function') {
            mraid.open(url);
            return;
        }
    } catch (e) {
        console.warn('CTA error (MRAID):', e);
    }

    try {
        const w = window.open(url, '_blank');
        if (!w) window.location.href = url;
    } catch (e) {
        console.warn('CTA error (fallback):', e);
        window.location.href = url;
    }
}
document.querySelector(".cta").addEventListener("click", handleCTA);
class AudioController {
    constructor(options = {}) {
        this.sounds = new Map();
        this._wasPlaying = new Set();
        this.userUnlockedAudio = false;
        this.globalMuted = true;
        this.sfxIndependent = !!options.sfxIndependent;
        this.isViewable = true;
        this.hostVolume = 1;
        this.masterVolume = 1;
        this.needsUserResume = false;
        this.sfxFanOut = Math.max(1, options.sfxFanOut || 4);

        this._bindFirstGesture();

        document.addEventListener('visibilitychange', () => {
            this.isViewable = !document.hidden;
            if (this.isViewable) {
                this._armResumeOnNextGesture();
            } else {
                this._pauseAll();
                this._armResumeOnNextGesture();
            }
        });

        this._wireMRAID();
    }

    setSfxIndependent(value) {
        this.sfxIndependent = !!value;
    }

    register(id, audioEl, opts = {}) {
        if (!id || !audioEl) return;

        const type = opts.type === 'sfx' ? 'sfx' : 'music';
        const loop = !!opts.loop;
        const baseVolume = this._clamp(typeof opts.volume === 'number' ? opts.volume : 1, 0, 1);

        audioEl.loop = loop;
        audioEl.volume = 0;
        audioEl.muted = true;

        this.sounds.set(id, {
            el: audioEl,
            type,
            loop,
            baseVolume,
            clones: new Set()
        });
    }

    setVolume(id, volume) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        entry.baseVolume = this._clamp(volume, 0, 1);
        this._applyVolume(entry);
    }

    setMasterVolume(volume) {
        this.masterVolume = this._clamp(volume, 0, 1);
        for (const entry of this.sounds.values()) this._applyVolume(entry);
    }

    unlockByGesture() {
        this.userUnlockedAudio = true;
        this.globalMuted = false;
        this._tryAutoResumeIfArmed();
    }

    mute() {
        this.globalMuted = true;
        this._pauseAll();
    }

    unmute() {
        this.globalMuted = false;
        this._armResumeOnNextGesture();
    }

    stop(id) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        entry.el.pause();
        try {
            entry.el.currentTime = 0;
        } catch (_) { }

        this._stopClones(entry);
        this._wasPlaying.delete(id);
    }

    pause(id) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        entry.el.pause();
        this._stopClones(entry);
    }

    play(id) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        if (!this.userUnlockedAudio) return;
        if (!this.isViewable) return;
        if (this._normHostVolume() <= 0) return;

        const allowedWhileMuted = this.sfxIndependent && entry.type === 'sfx';
        if (this.globalMuted && !allowedWhileMuted) return;

        // SFX fan-out (non-looping) via clones
        if (entry.type === 'sfx' && !entry.loop) {
            this._stopFinishedClones(entry);

            if (entry.clones.size >= this.sfxFanOut) {
                const oldest = entry.clones.values().next().value;
                if (oldest) {
                    try {
                        oldest.pause();
                    } catch (_) { }
                    entry.clones.delete(oldest);
                }
            }

            try {
                entry.el.currentTime = 0;
            } catch (_) { }

            const clone = entry.el.cloneNode(true);
            clone.muted = false;
            clone.loop = false;
            clone.volume = this._effectiveVolume(entry);

            if (entry.el.parentNode) entry.el.parentNode.appendChild(clone);
            entry.clones.add(clone);

            clone.play().catch(() => {
                try {
                    clone.remove();
                } catch (_) { }
                entry.clones.delete(clone);
            });

            clone.addEventListener('ended', () => {
                entry.clones.delete(clone);
                try {
                    clone.remove();
                } catch (_) { }
            });

            return;
        }

        entry.el.muted = false;
        entry.el.loop = entry.loop;
        this._applyVolume(entry);

        entry.el
            .play()
            .then(() => {
                this._wasPlaying.add(id);
                this.needsUserResume = false;
            })
            .catch(() => {
                this._armResumeOnNextGesture();
            });
    }

    playMusic(id) {
        this.play(id);
    }

    playSfx(id) {
        this.play(id);
    }

    fadeTo(id, target = 1, durationMs = 300) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        const startTime = performance.now();
        const from = entry.baseVolume;
        const to = this._clamp(target, 0, 1);

        const tick = (now) => {
            const t = Math.min(1, (now - startTime) / durationMs);
            entry.baseVolume = from + (to - from) * t;
            this._applyVolume(entry);
            if (t < 1) requestAnimationFrame(tick);
        };

        requestAnimationFrame(tick);
    }

    fadeIn(id, durationMs = 300) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        const original = entry.baseVolume;
        entry.baseVolume = 0;
        this.play(id);
        this.fadeTo(id, original || 1, durationMs);
    }

    fadeOut(id, durationMs = 300) {
        const entry = this.sounds.get(id);
        if (!entry) return;

        const original = entry.baseVolume;
        this.fadeTo(id, 0, durationMs);
        setTimeout(() => this.pause(id), durationMs + 10);
        entry.baseVolume = original;
    }

    _pauseAll() {
        for (const [, entry] of this.sounds) {
            try {
                entry.el.pause();
            } catch (_) { }

            for (const clone of entry.clones) {
                try {
                    clone.pause();
                } catch (_) { }
            }

            this._stopFinishedClones(entry);
        }
    }

    _bindFirstGesture() {
        const onFirstGesture = () => {
            this.unlockByGesture();
            window.removeEventListener('pointerdown', onFirstGesture, true);
            window.removeEventListener('click', onFirstGesture, true);
        };

        window.addEventListener('pointerdown', onFirstGesture, true);
        window.addEventListener('click', onFirstGesture, true);
    }

    _armResumeOnNextGesture() {
        if (this.needsUserResume) return;
        this.needsUserResume = true;

        const onGesture = () => {
            this._tryAutoResumeIfArmed();
            window.removeEventListener('pointerdown', onGesture, true);
            window.removeEventListener('click', onGesture, true);
        };

        window.addEventListener('pointerdown', onGesture, true);
        window.addEventListener('click', onGesture, true);
    }

    _tryAutoResumeIfArmed() {
        if (!this.needsUserResume) return;
        if (!this.userUnlockedAudio) return;
        if (!this.isViewable) return;
        if (this._normHostVolume() <= 0) return;
        if (this.globalMuted) return;

        this.needsUserResume = false;
        for (const id of [...this._wasPlaying]) this.play(id);
        this._wasPlaying.clear();
    }

    _wireMRAID() {
        // Non-MRAID fallback: use document/page visibility and focus events
        if (typeof mraid === 'undefined') {
            if (this._visibilityWired) return;
            this._visibilityWired = true;

            const onHide = () => {
                this.isViewable = false;
                this._pauseAll();
                this._armResumeOnNextGesture();
            };

            const onShow = () => {
                this.isViewable = true;
                this._armResumeOnNextGesture();
            };

            document.addEventListener('visibilitychange', () => {
                document.hidden ? onHide() : onShow();
            });

            window.addEventListener('pagehide', onHide);
            window.addEventListener('pageshow', onShow);
            window.addEventListener('blur', onHide);
            window.addEventListener('focus', onShow);

            if (typeof document.hidden === 'boolean' && document.hidden) onHide();
            else onShow();

            return;
        }

        const init = () => {
            if (typeof mraid.isViewable === 'function') {
                this.isViewable = !!mraid.isViewable();
            }

            let version = 0;
            try {
                version = parseFloat(mraid.getVersion && mraid.getVersion());
            } catch (_) { }

            const onViewableChange = (isViewable) => {
                this.isViewable = !!isViewable;
                if (this.isViewable) {
                    this._armResumeOnNextGesture();
                } else {
                    this._pauseAll();
                    this._armResumeOnNextGesture();
                }
            };

            // MRAID 3.0: exposureChange (preferred), fallback to viewableChange
            const onExposureChange = (payload) => {
                let exposure = null;

                if (typeof payload === 'number') {
                    exposure = payload;
                } else if (payload && typeof payload === 'object') {
                    const v =
                        payload.exposedPercentage != null ? payload.exposedPercentage :
                            payload.exposurePercentage != null ? payload.exposurePercentage :
                                payload.percentage != null ? payload.percentage :
                                    payload.exposure != null ? payload.exposure :
                                        null;
                    if (v != null) exposure = +v;
                }

                // If payload is unusable, approximate from isViewable()
                if (exposure == null && typeof mraid.isViewable === 'function') {
                    exposure = mraid.isViewable() ? 100 : 0;
                }

                const norm = isFinite(exposure)
                    ? (exposure > 1.0001 ? this._clamp(exposure / 100, 0, 1) : this._clamp(exposure, 0, 1))
                    : 0;

                this.isViewable = norm > 0;
                if (this.isViewable) {
                    this._armResumeOnNextGesture();
                } else {
                    this._pauseAll();
                    this._armResumeOnNextGesture();
                }
            };

            if (version >= 3) {
                let exposureWired = false;
                try {
                    mraid.addEventListener('exposureChange', onExposureChange);
                    exposureWired = true;
                } catch (_) { }
                if (!exposureWired) mraid.addEventListener('viewableChange', onViewableChange);
            } else {
                mraid.addEventListener('viewableChange', onViewableChange);
            }

            try {
                mraid.addEventListener('stateChange', (state) => {
                    if (state === 'hidden') {
                        this._pauseAll();
                        this._armResumeOnNextGesture();
                    }
                });
            } catch (_) { }

            // MRAID 3.0: audioVolumeChange
            try {
                mraid.addEventListener('audioVolumeChange', (vol) => {
                    if (vol != null) {
                        const n = +vol;
                        this.hostVolume = isFinite(n) ? n : 1;

                        if (this._normHostVolume() <= 0) {
                            this._pauseAll();
                            this._armResumeOnNextGesture();
                        } else {
                            this._armResumeOnNextGesture();
                        }
                    }
                });
            } catch (_) { }
        };

        if (mraid.getState && mraid.getState() === 'loading') {
            mraid.addEventListener('ready', init);
        } else {
            init();
        }
    }

    _applyVolume(entry) {
        const v = this._effectiveVolume(entry);
        entry.el.volume = v;
        for (const clone of entry.clones) clone.volume = v;
    }

    _effectiveVolume(entry) {
        const host = this._normHostVolume();
        const allowedWhileMuted = this.sfxIndependent && entry.type === 'sfx';
        const muteFactor = this.globalMuted && !allowedWhileMuted ? 0 : 1;
        return this._clamp(entry.baseVolume * this.masterVolume * host * muteFactor, 0, 1);
    }

    _normHostVolume() {
        const v = this.hostVolume;
        if (!isFinite(v)) return 1;
        return v > 1.0001 ? this._clamp(v / 100, 0, 1) : this._clamp(v, 0, 1);
    }

    _stopClones(entry) {
        for (const clone of entry.clones) {
            try {
                clone.pause();
            } catch (_) { }
            try {
                clone.remove();
            } catch (_) { }
        }
        entry.clones.clear();
    }

    _stopFinishedClones(entry) {
        for (const clone of [...entry.clones]) {
            if (clone.ended || clone.paused) {
                try {
                    clone.remove();
                } catch (_) { }
                entry.clones.delete(clone);
            }
        }
    }

    _clamp(value, min, max) {
        return Math.max(min, Math.min(max, value));
    }
}

const ac = new AudioController();
ac.register("bgm", new Audio("assets/bgm.mp3"), {
    type: "music",
    loop: 1,
    volume: 0.8
});
const hand = document.querySelector(".hand")
document.addEventListener("click", () => {
    ac.play("bgm");
    if (!hand) return;
    hand.remove();
}, { once: 1 });

document.addEventListener("pointerup", () => {
    ac.play("bgm");
    if (!hand) return;
    hand.remove();
}, { once: 1 });
document.querySelector(".scroll-content").addEventListener("scroll", () => {
    ac.play("bgm");
    if (!hand) return;
    hand.remove();
}, { once: 1 })



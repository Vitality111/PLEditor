document.addEventListener('contextmenu', e => e.preventDefault()), document.addEventListener('selectstart', e => e.preventDefault()), ['img', 'video', 'audio'].forEach(e => { document.querySelectorAll(e).forEach(e => { e.setAttribute('draggable', 'false'), e.style.webkitTouchCallout = 'none', e.style.userSelect = 'none' }) });
// ==== (iOS / Android) ====
const IOS_URL = 'https://apps.apple.com/us/app/cleanup-app-phone-cleaner/id1541639300';

function isIOS() {
    return /iPad|iPhone|iPod/i.test(navigator.userAgent) || /iOS/i.test(navigator.platform);
}

function getStoreUrl() {
    return IOS_URL;
}

let ctaLocked = false;
function lockCTA(ms = 1500) {
    ctaLocked = true;
    setTimeout(() => (ctaLocked = false), ms);
}

function handleCTA() {
    if (ctaLocked) return;
    lockCTA();

    const url = getStoreUrl();

    try {
        if (typeof FbPlayableAd !== 'undefined' && typeof FbPlayableAd.onCTAClick === 'function') {
            FbPlayableAd.onCTAClick();
            return;
        }
    } catch (e) {
        console.warn('CTA error (Facebook):', e);
    }

    try {
        if (typeof AL !== 'undefined') {
            if (typeof AL.openStoreUrl === 'function') {
                try { AL.openStoreUrl(); return; } catch (_) { }
                try { AL.openStoreUrl(url); return; } catch (_) { }
            }

            if (typeof AL.openUrl === 'function') {
                AL.openUrl(url);
                return;
            }
        }
    } catch (e) {
        console.warn('CTA error (AppLovin):', e);
    }

    try {
        if (typeof mraid !== 'undefined' && typeof mraid.open === 'function') {
            mraid.open(url);
            return;
        }
    } catch (e) {
        console.warn('CTA error (MRAID):', e);
    }

    try {
        const w = window.open(url, '_blank');
        if (!w) window.location.href = url;
    } catch (e) {
        console.warn('CTA error (fallback):', e);
        window.location.href = url;
    }
}

document.querySelector(".app").addEventListener("click", handleCTA);